
        <!-- Page Content -->
   		<h1>GESTION HOTEL</h1>
        <hr>
          <div >Table des hotels:</div>

          <div ><?= $table ?></div>

          <div >DATE ET HEURE DE LA DERNIERE MAJ</div>
 
      <!-- /.container-fluid -->