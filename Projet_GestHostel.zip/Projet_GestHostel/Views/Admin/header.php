<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="Projet Labo">
  <meta name="author" content="Evoliris Full STack Dev">
  <link rel="stylesheet" href="Contents/style.css">
  <title>GestHotel Admin</title>
</head>

<body>
  <nav >
    <a  href="index.html">GestHotel Admin</a>
    <!-- Sidebar -->
      <ul >
        <li >
          <a  href="index.html">
            <span>Tableau de bord</span>
          </a>
        </li>
        <li >
          <a href="#">
            <span>Hotels/Chambres</span>
          </a>
            <h6 >Hotels:</h6>
            <a  href="#">Voir/modifier</a>
            <a  href="#">Ajouter</a>
            <div ></div>
            <h6 >Chambres:</h6>
            <a >Voir/modifier</a>
            <a >Ajouter</a>
        </li>
      </ul>
 </nav>