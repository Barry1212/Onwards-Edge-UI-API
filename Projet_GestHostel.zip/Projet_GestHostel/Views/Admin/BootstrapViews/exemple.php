    <div id="content-wrapper">

      <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
          <li class="breadcrumb-item">
            <a href="index.html">Tableau de Bord</a>
          </li>
          <li class="breadcrumb-item active">Page Blanche (Model)</li>
        </ol>

        <!-- Page Content -->
        <h1>Page Blanche (Model)</h1>
        <hr>
        <p>Ceci est le corp de la page . (Inserer ici les formulaires, tables, etc ...)</p>

      </div>
      <!-- /.container-fluid -->