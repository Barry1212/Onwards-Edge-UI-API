<div class="container">
	<h2>Détails de l'hôtel</h2>
	<?= $p; ?>
</div>

