<div style="margin: 25px;">
<form method="POST" action="">
	<textarea cols="40" rows="10" name="msg"></textarea>
	<br>
	<input type="submit" value="Envoyer">
</form>
</div>