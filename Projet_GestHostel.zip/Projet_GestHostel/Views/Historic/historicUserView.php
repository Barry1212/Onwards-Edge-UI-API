<div id="historicUser">
		
		<h2>Historique de l'utilisateur:</h2>

			
	<table class="tableHistoricUser">
		<tr>
			<th>Nom de l'Hotel</th>
			<th>Nom de la Chambre</th>
			<th>Date de début</th>
			<th>Date de fin</th>
			<th>Prix Total</th>
			<th>Annulation</th>
		</tr>
		<?= $result ?>

	</table>

	</div>