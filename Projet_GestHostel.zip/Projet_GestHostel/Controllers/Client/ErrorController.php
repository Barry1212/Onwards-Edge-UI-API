<?php 
echo "<br>";
echo "<h2>Erreur 404</h2>";
echo "<p>Page introuvable!</p>";
 ?>
 