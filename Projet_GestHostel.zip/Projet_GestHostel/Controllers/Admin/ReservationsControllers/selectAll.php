<?php 
require_once("Models/reservation.php");

try
{
	$table = "<table class='tableAdmin'>";
	$table .= "<tr><th>id</th><th>Prix</th><th>Client</th></tr>";
	$reservations = $con->getAll();
	foreach ($reservations as $reservation) {
	
		$table .= '<tr><td class="tdTableAdmin">' . $reservation['reservationId'] . '</td>';
		$table .= '<td class="tdTableAdmin">' . $reservation['totalPrice'] . '</td></tr>';
		$table .= '<td class="tdTableAdmin">' . $con->getByIdUser($reservation['user.userId'])["firstName"];
		// $table .= '<td class="tdTableAdmin">' . $reservation['reservationStars'] . '</td>';
		// $table .= '<td class="tdTableAdmin">' .$reservation["add_postCode"] . '</td>';
		// $table .= '<td class="tdTableAdmin">' .$reservation["add_streetName"] . '</td>';
		// $table .= '<td class="tdTableAdmin">' .$reservation["add_number"] . '</td>';
		// $table .= '<td class="tdTableAdmin">' .$reservation["add_country"] . '</td>';
		// $table .= '<td class="tdTableAdmin"><a class="btn-delete" href="index.php?section=delete&reservation=' . $reservation["reservationId"].'">&#128465;</a></td></tr>';
	}
	$table.="</table>";

	require_once("Views/Admin/ReservationsViews/selectAll.php");

}
catch(PDOException $e)
{
	echo $e->getMessage();
}


?>